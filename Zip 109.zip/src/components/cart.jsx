import "./cart.css";
const Cart = () => {
    return (
      <div className="cart-page">
        <h1>The Products in Your Cart</h1>
        <h3>Showing Items</h3>
      </div>
    );
  };
  
  export default Cart;
  