import "./about.css";
const About = () => {
    return (
      <div className="about-page">
        <h1>Online Store</h1>
        <h3>Created by Mark Courtright</h3>
      </div>
    );
  };
  
  export default About;
  